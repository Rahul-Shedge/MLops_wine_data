from setuptools import setup,find_packages

setup(
    name= "src",
    version= "0.0.1",
    description="First package on wineQ check",
    author="rahulshedge555",
    package=find_packages(),
    licencse="MIT"
)